document.addEventListener('deviceready', function () {
					var notificationOpenedCallback = function(jsonData) {
						console.log('notificationOpenedCallback: ' + JSON.stringify(jsonData));
  					};

  					window.plugins.OneSignal
					    .startInit('4aa4ffd1-3abd-4f18-8943-6d8f628443ff')
					    .handleNotificationOpened(notificationOpenedCallback)
					    .endInit();
					}, false);
				