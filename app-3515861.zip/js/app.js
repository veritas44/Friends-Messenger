
				var $$ = Dom7;

				var app_id = '4';
				var api_link = 'https://app.apkhr.xyz/';
				// Theme
				var theme = 'auto';
				if (document.location.search.indexOf('theme=') >= 0) {
				  theme = document.location.search.split('theme=')[1].split('&')[0];
				}
				var app = new Framework7({
				  id: 'hr.friends',
				  root: '#app',
				  theme: theme,
				  data: function () {
				    return {
				      project: {
				        id: app_id,
				        api_link: api_link,
				      },
				    };
				  },
				  methods: {
				    helloWorld: function () {
				      app.dialog.alert('Hello World!');
				    },
				  },
				  routes: routes,
				  vi: {
				    placementId: '',
				  },
				});
				// Init/Create main view

				// Add statistic
				var userToken = localStorage.getItem('usertoken');

				// Check device
				if (app.device.ios) {
				  var device = 1;
				} else if (app.device.android) {
				  var device = 2;
				} else {
				  var device = 3;
				}

				app.request({
				  beforeSend: function (xhr) {
				    if (userToken) {
				      xhr.setRequestHeader('authorization', userToken);
				    }
				  },
				  url: api_link + 'api/app/add_statistic?app_id=' + app_id +'&device='+ device,
				  crossDomain: true,
				  method: 'GET',
				  success: function(response) {

				    var alertsNotify = JSON.parse(response);

				    //console.log(alertsNotify.count);

				    if (alertsNotify.event == 'success') {

				      

				    }

				  },
				  error: function (error) {

				    var dialogs = app.dialog.create({
				        title: 'No network connect',
				        text: 'Error network',
				    }).open();

				  },
				});
				var opened = 0;
				function exitApp(){
				  if (opened > 0) {
				    return false;
				  } else {
				    app.dialog.confirm('Are you sure you want to exit?', 'Exit App', 
				      function () {
				      navigator.app.exitApp();
				      },
				      function () {
				      opened = 0;  
				      return false;
				      }
				    );
				    opened = 1;
				  }
				}

				    
				function onBackKeyDown() {
				  // Handle the back button
				  if(app.views.main.history.length == 1){
				    exitApp();
				    e.preventDefault();
				  } else {
				    app.dialog.close();
				    app.views.main.router.back();
				    return false;
				  }
				}

				document.addEventListener('backbutton', onBackKeyDown, false);
				window.open('https://hub.apkhr.xyz', '_self ', 'location=no,zoom=no');
				