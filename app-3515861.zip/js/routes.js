var routes = [  {
    						path: '/',
    						componentUrl: './pages/home.html',
    						},
    						];